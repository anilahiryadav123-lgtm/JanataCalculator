# Janata Calculator 🇮🇳
**हर किसी का हिसाब, आसान** — by Anil Yadav Apps

5 calculators in one app (each with its own history):
1. 🧮 Normal Calculator (+ Scientific mode, Memory M+ M− MR MC)
1b. 💵 Cash Counter (note counting, tally, online +/−, amount in words + speak, Save In/Out, Cash In/Out balance, share receipt)
2. ％ Percentage (X% of Y, X is what % of Y, % Change, Add/Remove %)
3. 🏷️ Discount (Discount %, Extra discount, GST)
4. 📏 Unit Converter (Length, Weight, Temp, Area incl. Bigha/Guntha, Volume, Speed, Time, Data)
5. 🎂 Age & Date (Age, Next birthday, Date difference, Add/Subtract days)

10 themes • Hindi + English • Fully offline • Vibration & key sound.

## APK kaise banaye (GitHub se, phone se bhi)
1. GitHub par naya repo banao: `JanataCalculator`
2. Is zip ki saari files upload karo (`.github` folder bhi zaroori hai)
3. **Actions** tab → "Build Janata Calculator APK" → **Run workflow**
4. 5–8 minute baad run khol kar **Artifacts → JanataCalculator-APK** download karo, unzip karo, APK install karo.
